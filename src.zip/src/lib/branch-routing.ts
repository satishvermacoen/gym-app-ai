"use client";

/**
 * Replace the first URL segment with the new branchId and preserve query/hash.
 * Examples:
 *   /old/members?status=active   => /new/members?status=active
 *   /                             => /new/dashboard
 */
export function buildPathForBranchSwitch(
  pathname: string,
  newBranchId: string,
  queryString?: string,
  hash?: string
) {
  const cleanHash = hash ?? (typeof window !== "undefined" ? window.location.hash : "");
  const qs = queryString && queryString.length > 0 ? `?${queryString}` : "";

  const segments = pathname.split("/").filter(Boolean);
  // If we're not currently on a branch route, send them to dashboard
  if (segments.length === 0) {
    return `/${newBranchId}/dashboard${qs}${cleanHash}`;
  }

  // Replace the first segment with the new branch id
  segments[0] = newBranchId;
  return `/${segments.join("/")}${qs}${cleanHash}`;
}
