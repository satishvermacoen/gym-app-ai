import React from 'react'

const page = () => {
  return (
    <div className='m-2 p-4'>
        <h1 className="text-2xl font-bold">Empolyee Dashboard</h1>
    </div>
  )
}

export default page