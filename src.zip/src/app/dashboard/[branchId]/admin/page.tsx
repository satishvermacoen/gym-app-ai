// app/(main)/[branchId]/page.tsx
export default function DashboardPage() {
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-bold">Super Admin Dashboard</h1>
      
    </div>
  );
}
