"use client";
import React from "react";
import { AppSidebar } from "@/components/layout/app-sidebar";
import { SiteHeader } from "@/components/layout/site-header";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";

import { useMeQuery } from "@/features/auth/hooks/useMeQuery";
import { useRouter } from "next/navigation";



export default function DashboardLayout({ children }: { children: React.ReactNode }) {

  return (
    <div className="min-h-screen">
      <SidebarProvider style={{ "--sidebar-width": "264px" } as React.CSSProperties}>
        <AppSidebar variant="inset" />
        <SidebarInset>
          <SiteHeader />
          <main className="min-h-screen">{children}</main>
        </SidebarInset>
      </SidebarProvider>
    </div>
  );
}