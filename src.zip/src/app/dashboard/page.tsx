"use client";
// app/(main)/[branchId]/page.tsx


import { ChartAreaInteractive } from "@/components/charts/chart-area-interactive";
import { DataTable } from "@/components/data-table/data-table";
import { SectionCards } from "@/components/layout/section-cards";
import data from "@/components/data.json"

import { useMeQuery } from "@/features/auth/hooks/useMeQuery";



export default function Page() {


  const { data: user, isLoading, isError, error, status  } = useMeQuery();


  console.log("user", user, isLoading, isError, error, status);


  
  return (
    <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <div>

              </div>
              <SectionCards />
              <div className="px-4 lg:px-6">
                <ChartAreaInteractive />
              </div>
              {/* <DataTable data={data} /> */}
            </div>
          </div>
        </div>
    
  );
}
