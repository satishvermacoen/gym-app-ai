import { useQuery } from "@tanstack/react-query";
import { API_ROUTES } from "@/constants/auth.api-route";
import { api } from "@/lib/api";
import { User, UserSchema } from "@/schemas/user/login.schema";

export const qk = {
  me: () => ["auth", "me"] as const,
};

async function fetchMe(): Promise<User> {
  const { data } = await api.get(API_ROUTES.auth.me);
  return UserSchema.parse(data?.data ?? data);
}

export function useMeQuery(enabled = true) {
  return useQuery({
    queryKey: qk.me(),
    queryFn: fetchMe,
    enabled,
    staleTime: 5 * 60_000,
    retry: (count, error: any) => {
      if (String(error?.message || "").toLowerCase().includes("unauthorized")) return false;
      return count < 2;
    },
  });
}