import { useMutation, useQueryClient } from "@tanstack/react-query";
import { sendLoginOtp, verifyLoginOtp } from "@/features/auth/services/login-otp.service";
import type { SendLoginOtpInput, VerifyLoginOtpInput } from "@/schemas/user/auth.login-otp.schema";
import { setAccessToken } from "@/lib/auth-token"; // if you use header-based tokens, else safe to leave as no-op

export function useSendLoginOtp() {
  return useMutation({
    mutationFn: (payload: SendLoginOtpInput) => sendLoginOtp(payload),
  });
}

export function useVerifyLoginOtp() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: (payload: VerifyLoginOtpInput) => verifyLoginOtp(payload),
    onSuccess: async (res) => {
      // if server returned tokens in body, save them; if cookie-only, this is harmless
      if (res?.accessToken) setAccessToken(res.accessToken);
      await qc.invalidateQueries({ queryKey: ["auth", "me"] });
    },
  });
}
