// src/features/auth/hooks/use.Signup.Auth.ts
import { useMutation } from "@tanstack/react-query";
import { registerUser, verifyEmailOtp } from "@/features/auth/services/signup.service";
import type { SignupInput, VerifyEmailInput } from "@/schemas/user/signup.schema";

export function useSignup() {
  return useMutation({
    mutationFn: (payload: SignupInput | FormData) =>
      payload instanceof FormData ? registerUser(payload) : registerUser(payload),
  });
}

export function useVerifyEmail() {
  return useMutation({
    mutationFn: (payload: VerifyEmailInput) => verifyEmailOtp(payload),
  });
}
