import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { API_ROUTES } from "@/constants/auth.api-route";
import { api } from "@/lib/api";
import { setAccessToken } from "@/lib/auth-token";
import { LoginInput, LoginResult, LoginResultSchema } from "@/schemas/user/login.schema";
import { z } from "zod";

export function useLogin() {
  const qc = useQueryClient();

  async function login(payload: LoginInput): Promise<LoginResult> {
    // using your existing endpoint & zod schema
    const { data } = await api.post(API_ROUTES.auth.login, payload);
    const parsed = LoginResultSchema.parse(data?.data ?? data);
    setAccessToken(parsed.accessToken ?? null);
    return parsed;
  }

  return useMutation({
    mutationFn: login,
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ["auth", "me"] });
    },
  });
}

export function useLogout() {
  const router = useRouter();
  const qc = useQueryClient();

  async function logout() {
    await api.post(API_ROUTES.auth.logout);
  }

  return useMutation({
    mutationFn: logout,
    onSettled: async () => {
      setAccessToken(null);
      await qc.resetQueries(); // clear caches
      router.push("/login");
    },
  });
}