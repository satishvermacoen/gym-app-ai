"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";

import { LoginSchema, type LoginInput, type LoginResult } from "@/schemas/user/login.schema";
import { SendLoginOtpSchema, VerifyLoginOtpSchema, type SendLoginOtpInput, type VerifyLoginOtpInput } from "@/schemas/user/auth.login-otp.schema";

import { useLogin } from "@/features/auth/hooks/use.Login.Auth";
import { useSendLoginOtp, useVerifyLoginOtp } from "@/features/auth/hooks/use.LoginOTP";

import { GoogleIcon } from "@/assets/files/Logo";
import { loginWithGoogle } from "@/features/auth/services/signup.service";

import { Button } from "@/components/ui/button";
import Link from "next/link";

type Mode = "password" | "otp";

export default function LoginForm() {
  const router = useRouter();
  const qc = useQueryClient();

  // ui state
  const [mode, setMode] = useState<Mode>("password");
  const [serverError, setServerError] = useState<string | null>(null);
  const [sentEmail, setSentEmail] = useState<string>("");
  const [countdown, setCountdown] = useState<number>(0); // seconds until resend enabled

  // password login
  const { mutateAsync: login, isPending: isPwdPending } = useLogin();
  const pwdForm = useForm<LoginInput>({
    resolver: zodResolver(LoginSchema),
    defaultValues: { email: "", password: "" },
    mode: "onSubmit",
  });

  // otp step 1: send
  const sendForm = useForm<SendLoginOtpInput>({
    resolver: zodResolver(SendLoginOtpSchema),
    defaultValues: { email: "" },
    mode: "onSubmit",
  });
  const { mutateAsync: sendOtp, isPending: isSendPending } = useSendLoginOtp();

  // otp step 2: verify
  const verifyForm = useForm<VerifyLoginOtpInput>({
    resolver: zodResolver(VerifyLoginOtpSchema),
    defaultValues: { email: "", otp: "" },
    mode: "onSubmit",
  });
  const { mutateAsync: verifyOtp, isPending: isVerifyPending } = useVerifyLoginOtp();

  // derived flags
  const canResend = useMemo(() => countdown <= 0, [countdown]);

  useEffect(() => {
    if (countdown <= 0) return;
    const t = setInterval(() => setCountdown((s) => s - 1), 1000);
    return () => clearInterval(t);
  }, [countdown]);

  async function handlePasswordLogin(values: LoginInput) {
  setServerError(null);
  try {
    await login(values) as LoginResult;
    router.push("/dashboard"); // ⬅️ changed from "/main"
  } catch (err: any) {
    setServerError(err.message || "Login failed");
  }
}

  async function handleSendOtp(values: SendLoginOtpInput) {
    setServerError(null);
    try {
      const res = await sendOtp(values);
      setSentEmail(res.email);
      setCountdown(Math.ceil((res.ttlMs ?? 600000) / 1000)); // fallback 10 min
      // seed email into verify form
      verifyForm.setValue("email", values.email);
    } catch (err: any) {
      setServerError(err.message || "Failed to send OTP");
    }
  }

  async function handleVerifyOtp(values: VerifyLoginOtpInput) {
  setServerError(null);
  try {
    await verifyOtp(values);

    await qc.invalidateQueries({ queryKey: ["auth", "me"] });
    router.push("/dashboard"); // ⬅️ changed from branch-based "/main"
  } catch (err: any) {
    setServerError(err.message || "Invalid OTP");
  }
}

  return (
    <div className="max-w-sm p-1 space-y-4">
      <div className="text-center mb-4">
        <h1 className="text-3xl font-bold text-gray-800">Welcome Back!</h1>
        <p className="text-xs text-gray-500 mt-2">Use password or one-time code</p>
      </div>

      {/* Mode Switch */}
      <div className="grid grid-cols-2 rounded-lg border overflow-hidden">
        <button
          type="button"
          onClick={() => setMode("password")}
          className={`px-3 py-2 text-sm ${mode === "password" ? "bg-gray-100 font-semibold" : ""}`}
        >
          Password
        </button>
        <button
          type="button"
          onClick={() => setMode("otp")}
          className={`px-3 py-2 text-sm ${mode === "otp" ? "bg-gray-100 font-semibold" : ""}`}
        >
          OTP (Email)
        </button>
      </div>

      {mode === "password" ? (
        <form onSubmit={pwdForm.handleSubmit(handlePasswordLogin)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium">Email</label>
            <input
              type="email"
              autoComplete="username"
              {...pwdForm.register("email")}
              className="mt-1 w-full rounded border px-3 py-2"
              placeholder="you@example.com"
            />
            {pwdForm.formState.errors.email && (
              <p className="text-sm text-red-600">{pwdForm.formState.errors.email.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium">Password</label>
            <input
              type="password"
              autoComplete="current-password"
              {...pwdForm.register("password")}
              className="mt-1 w-full rounded border px-3 py-2"
              placeholder="••••••••"
            />
            {pwdForm.formState.errors.password && (
              <p className="text-sm text-red-600">{pwdForm.formState.errors.password.message}</p>
            )}
          </div>

          {serverError && <p className="text-sm text-red-600">{serverError}</p>}

          <Button type="submit" disabled={isPwdPending} className="w-full transition-all duration-200 hover:scale-105">
            {isPwdPending ? "Signing in..." : "Sign in"}
          </Button>
        </form>
      ) : (
        <>
          {/* OTP Step 1: Send */}
          <form onSubmit={sendForm.handleSubmit(handleSendOtp)} className="space-y-3">
            <div>
              <label className="block text-sm font-medium">Email</label>
              <input
                type="email"
                {...sendForm.register("email")}
                className="mt-1 w-full rounded border px-3 py-2"
                placeholder="you@example.com"
                disabled={!!sentEmail && !canResend}
              />
              {sendForm.formState.errors.email && (
                <p className="text-sm text-red-600">{sendForm.formState.errors.email.message}</p>
              )}
            </div>

            <div className="flex items-center justify-between gap-2">
              <Button type="submit" disabled={isSendPending || (!canResend && !!sentEmail)} className="flex-1">
                {isSendPending ? "Sending..." : sentEmail ? (canResend ? "Resend OTP" : "OTP Sent") : "Send OTP"}
              </Button>
              {!!sentEmail && (
                <span className="text-xs text-muted-foreground w-24 text-right">
                  {canResend ? "You can resend now" : `Resend in ${countdown}s`}
                </span>
              )}
            </div>
          </form>

          {/* OTP Step 2: Verify (visible once sent) */}
          {!!sentEmail && (
            <form onSubmit={verifyForm.handleSubmit(handleVerifyOtp)} className="space-y-3 pt-2">
              <div>
                <label className="block text-sm font-medium">Enter 6-digit OTP</label>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={8}
                  {...verifyForm.register("otp")}
                  className="mt-1 w-full rounded border px-3 py-2 tracking-widest"
                  placeholder="••••••"
                />
                {verifyForm.formState.errors.otp && (
                  <p className="text-sm text-red-600">{verifyForm.formState.errors.otp.message}</p>
                )}
              </div>

              {/* keep email synced for submit */}
              <input type="hidden" {...verifyForm.register("email")} />

              {serverError && <p className="text-sm text-red-600">{serverError}</p>}

              <Button type="submit" disabled={isVerifyPending} className="w-full">
                {isVerifyPending ? "Verifying..." : "Verify & Sign in"}
              </Button>
            </form>
          )}
        </>
      )}

      {/* Social / Sign up */}
      <div>
        <p className="text-xs text-muted-foreground text-center mt-4">Sign In with Google</p>
        <Button
          type="button"
          variant="outline"
          onClick={loginWithGoogle}
          className="w-full mt-2 flex items-center justify-center gap-4 transition-all duration-200 hover:bg-gray-100 hover:scale-105"
        >
          <GoogleIcon />
          Continue with Google
        </Button>

        <Link href="/sign-up" className="text-sm text-blue-60">
          <Button variant="outline" className="w-full mt-4 flex items-center justify-center gap-4 transition-all duration-200 hover:bg-gray-100 hover:scale-105">
            Sign Up with Email
          </Button>
        </Link>
      </div>
    </div>
  );
}
