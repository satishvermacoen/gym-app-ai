import { api } from "@/lib/api";
import { API_ROUTES } from "@/constants/auth.api-route";
import { OtpSendResponseSchema, OtpVerifyResponseSchema, type SendLoginOtpInput, type VerifyLoginOtpInput } from "@/schemas/user/auth.login-otp.schema";

export async function sendLoginOtp(payload: SendLoginOtpInput) {
  const { data } = await api.post(API_ROUTES.auth.sendLoginOtp, payload);
  return OtpSendResponseSchema.parse(data?.data ?? data);
}

export async function verifyLoginOtp(payload: VerifyLoginOtpInput) {
  const { data } = await api.post(API_ROUTES.auth.verifyLoginOtp, payload);
  return OtpVerifyResponseSchema.parse(data?.data ?? data);
}
