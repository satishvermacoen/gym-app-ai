// src/features/auth/services/signup.service.ts
import { api } from "@/lib/api";
import { API_ROUTES } from "@/constants/auth.api-route";
import { z } from "zod";
import type { SignupInput, VerifyEmailInput } from "@/schemas/user/signup.schema";

// ---- Response schemas that match your backend ----
export const RegisterResponseSchema = z.object({
  email: z.string().email(),
  ttlMs: z.number().int().nonnegative(), // e.g. 595519
});
export type RegisterResponse = z.infer<typeof RegisterResponseSchema>;

export const VerifyResponseSchema = z.object({
  emailVerified: z.boolean(),
});
export type VerifyResponse = z.infer<typeof VerifyResponseSchema>;

// ---- Services ----

/**
 * Register user and trigger email OTP.
 * Accepts a plain object (SignupInput) or FormData.
 */
export async function registerUser(input: SignupInput | FormData): Promise<RegisterResponse> {
  const payload = input instanceof FormData ? input : toFormData(input);
  const { data } = await api.post(API_ROUTES.auth.signup, payload);
  return RegisterResponseSchema.parse(data?.data ?? data);
}

/**
 * Verify email with OTP.
 * Backend returns only { emailVerified: true }.
 */
export async function verifyEmailOtp(input: VerifyEmailInput): Promise<VerifyResponse> {
  const { data } = await api.post(API_ROUTES.auth.verifyEmail, input);
  return VerifyResponseSchema.parse(data?.data ?? data);
}

// ---- Helpers ----
function toFormData(p: SignupInput): FormData {
  const fd = new FormData();
  Object.entries(p).forEach(([k, v]) => {
    if (v == null) return;
    if (k === "avatar" && typeof window !== "undefined" && v instanceof File) {
      fd.append("avatar", v);
    } else {
      fd.append(k, String(v));
    }
  });
  return fd;
}

/** Optional Google OAuth redirect helper (unchanged) */
export function loginWithGoogle() {
  const base = process.env.NEXT_PUBLIC_API_URL ?? "";
  const path =
    (API_ROUTES as any)?.auth?.loginWithGoogle ??
    (API_ROUTES as any)?.auth?.googleLogin ??
    "/auth/google";
  window.location.href = `${base}${path}`;
}
