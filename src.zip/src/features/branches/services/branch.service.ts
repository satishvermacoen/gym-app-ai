import { API_ROUTES } from "@/constants/branch.api-route";
import { api } from "@/lib/api"; // your configured Axios instance
import {
  BranchDashboardResponseSchema,
  BranchDashboardData,
} from "@/schemas/branch/branch-dashboard.schema";
import {
  BranchListResponseSchema,
  BranchListItem,
} from "@/schemas/branch/branch-list.schema";
import { Branch } from "@/schemas/branch/branch.schema";

/** Fetch the dashboard for a single branch */
export async function getBranchDashboard(
  branchId: string,
  opts?: { signal?: AbortSignal }
): Promise<BranchDashboardData> {
  const { data } = await api.get(`/branches/${branchId}/dashboard`,);
  const parsed = BranchDashboardResponseSchema.parse(data);
  return parsed.data;
}

/** Fetch all branches for the current owner */
export async function getBranchList(): Promise<BranchListItem[]> {
  const { data } = await api.get(`/branches`);
  const parsed = BranchListResponseSchema.parse(data);
  return parsed.data;
}


export async function fetchMyBranches(): Promise<Branch[]> {
  const res = await api.get(API_ROUTES.branchesInfo.list);
  return res.data?.data?.ownedBranches ?? [];
}