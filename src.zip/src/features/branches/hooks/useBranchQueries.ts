import { useQuery, QueryClient, keepPreviousData } from "@tanstack/react-query";
import { qk } from "@/queries/keys";
import { getBranchDashboard, getBranchList } from "@/features/branches/services/branch.service";
import type { BranchDashboardData } from "@/schemas/branch/branch-dashboard.schema";
import type { BranchListItem } from "@/schemas/branch/branch-list.schema";

export function useBranchDashboardQuery(branchId?: string, opts?: { enabled?: boolean; staleTime?: number }) {
  return useQuery<BranchDashboardData>({
    queryKey: branchId ? qk.branchDashboard(branchId) : ["branchDashboard", "__none__"],
    queryFn: () => getBranchDashboard(branchId!),
    enabled: !!branchId && (opts?.enabled ?? true),
    staleTime: opts?.staleTime ?? 60_000,
    placeholderData: keepPreviousData,
  });
}

export function useBranchListQuery() {
  return useQuery<BranchListItem[]>({
    queryKey: qk.branches(),
    queryFn: getBranchList,
    staleTime: 5 * 60_000,
  });
}

export async function prefetchBranchDashboard(qc: QueryClient, branchId: string) {
  await qc.prefetchQuery({ queryKey: qk.branchDashboard(branchId), queryFn: () => getBranchDashboard(branchId), staleTime: 60_000 });
}
console.log(prefetchBranchDashboard)

export async function prefetchBranches(qc: QueryClient) {
  await qc.prefetchQuery({ queryKey: qk.branches(), queryFn: getBranchList, staleTime: 5 * 60_000 });
}