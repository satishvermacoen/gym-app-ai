import { useQuery } from "@tanstack/react-query";
import { fetchMyBranches } from "@/features/branches/services/branch.service";

export function useMyBranches() {
  return useQuery({
    queryKey: ["my-branches"],
    queryFn: fetchMyBranches,
    staleTime: 5 * 60 * 1000,
  });
}
