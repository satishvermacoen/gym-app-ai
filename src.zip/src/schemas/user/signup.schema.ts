// src/schemas/User/signup.schema.ts
import { z } from "zod";

export const ROLE_ENUM = z.enum(["OWNER", "ADMIN", "MANAGER", "STAFF"]);

// In browser, File check; in SSR this still compiles
const FileLike = z
  .any()
  .refine(
    (f) => typeof window === "undefined" || f == null || f instanceof File,
    "Invalid file"
  );

export const SignupSchema = z.object({
  firstName: z.string().trim().min(1, "First name is required"),
  lastName: z.string().trim().min(1, "Last name is required"),
  email: z.email("Invalid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: ROLE_ENUM,
  avatar: FileLike.optional(),
});
export type SignupInput = z.infer<typeof SignupSchema>;

export const VerifyEmailSchema = z.object({
  email: z.email().trim(),
  otp: z.string().trim().min(4).max(8),
});
export type VerifyEmailInput = z.infer<typeof VerifyEmailSchema>;
