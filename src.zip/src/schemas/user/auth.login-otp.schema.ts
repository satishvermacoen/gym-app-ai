import { z } from "zod";
import { UserSchema } from "@/schemas/user/login.schema";

export const SendLoginOtpSchema = z.object({
  email: z.string().email(),
});
export type SendLoginOtpInput = z.infer<typeof SendLoginOtpSchema>;

export const VerifyLoginOtpSchema = z.object({
  email: z.email(),
  otp: z.string().trim().min(4).max(8), // your backend sends 6 digits; allow 4–8 to be flexible
});
export type VerifyLoginOtpInput = z.infer<typeof VerifyLoginOtpSchema>;

export const OtpSendResponseSchema = z.object({
  email: z.string().email(),
  ttlMs: z.number().int().positive(),
});

export const OtpVerifyResponseSchema = z.object({
  // your backend returns { user: loggedInUser } (cookies carry tokens)
  user: UserSchema,
  // tolerate optional tokens if you add them later
  accessToken: z.string().optional(),
  refreshToken: z.string().optional(),
});
