export type Branch = {
  _id: string;
  name: string;
};