// src/schemas/branch-dashboard.schema.ts
import { z } from "zod";

/** Common primitives */
const ObjectId = z.string().min(1);
const ISODate = z.iso.datetime({ offset: true });

/** Utilities */
const PinCode = z.union([z.string(), z.number()]).transform((v) => String(v));

/** Operating hours for each weekday */
export const OperatingHourSchema = z.object({
  day: z.string(),
  open: z.string(),  // e.g. "06:00 AM"
  close: z.string(), // e.g. "10:00 PM"
  isOpen: z.boolean(),
  _id: ObjectId,
});

/** Location (note: backend key 'adreessline1' as-is) */
export const LocationSchema = z.object({
  adreessline1: z.string().optional(), // API has this typo; preserved to match payload
  addressline2: z.string().optional(),
  city: z.string(),
  state: z.string(),
  pinCode: PinCode, // number here → coerced to string
  country: z.string(),
});

/** Contact info */
export const ContactSchema = z.object({
  mobile: z.string(),
  phone: z.string(),
  email: z.string().email(),
});

/** Member sub-documents */
export const MemberAddressSchema = z.object({
  street: z.string(),
  city: z.string(),
  state: z.string(),
  pinCode: PinCode, // string here in payload → coerced to string
});

export const PhysicalStatsSchema = z.object({
  weightKg: z.number(),
  heightCm: z.number(),
});

export const PersonalInfoSchema = z.object({
  firstName: z.string(),
  lastName: z.string(),
  dateOfBirth: ISODate,
  gender: z.string(),
  address: MemberAddressSchema,
  email: z.string().email(),
  mobileNumberMain: z.string(),
  alternateMobile: z.string(),
  physicalStats: PhysicalStatsSchema,
});

export const MembershipInfoSchema = z.object({
  membershiptype: z.string(),
  duration: z.string(),
  preferredStartDate: ISODate,
  specialRequests: z.string(),
  classInterests: z.array(z.string()),
});

export const EmergencyContactInfoSchema = z.object({
  fullName: z.string(),
  relationship: z.string(),
  mobileNumber: z.string(),
});

export const MemberSchema = z.object({
  _id: ObjectId,
  profilepic: z.string(),
  personalInfo: PersonalInfoSchema,
  membershipInfo: MembershipInfoSchema,
  emergencyContactInfo: EmergencyContactInfoSchema,
  paymentDetails: z.array(z.string()),
  branch: ObjectId,
  createdBy: ObjectId,
  isActive: z.boolean(),
  createdAt: ISODate,
  updatedAt: ISODate,
  __v: z.number().int(),
});

/** Staff (compact list for dashboard) */
export const StaffSchema = z.object({
  _id: ObjectId,
  firstName: z.string(),
  jobTitle: z.string(),
});

/** Main dashboard data block */
export const BranchDashboardDataSchema = z.object({
  _id: ObjectId,
  name: z.string(),
  location: LocationSchema,
  contact: ContactSchema,
  operatingHours: z.array(OperatingHourSchema),
  createdAt: ISODate,
  staffCount: z.number().int(),
  activeMemberCount: z.number().int(),
  membershipBreakdown: z.record(z.string(), z.number().int().nonnegative()),
  recentMembers: z.array(MemberSchema),
  monthlyExpenseTotal: z.number(),
  staffList: z.array(StaffSchema),
});

/** Full API response */
export const BranchDashboardResponseSchema = z.object({
  statusCode: z.number().int(),
  data: BranchDashboardDataSchema,
  message: z.string(),
  success: z.boolean(),
});



/** Types */
export type BranchDashboardResponse = z.infer<typeof BranchDashboardResponseSchema>;
export type BranchDashboardData = z.infer<typeof BranchDashboardDataSchema>;
export type Member = z.infer<typeof MemberSchema>;
