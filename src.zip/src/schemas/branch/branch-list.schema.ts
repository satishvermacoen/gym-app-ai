// src/schemas/branch-list.schema.ts
import { z } from "zod";
import { LocationSchema, ContactSchema, OperatingHourSchema } from "@/schemas/branch/branch-dashboard.schema";

/** A branch item in list response */
export const BranchListItemSchema = z.object({
  _id: z.string(),
  name: z.string(),
  location: LocationSchema,   // reuse from dashboard
  contact: ContactSchema,     // reuse
  owner: z.array(z.string()), // just IDs here
  operatingHours: z.array(OperatingHourSchema),
  staff: z.array(z.unknown()), // empty [] in response, may later hold staff objects
  createdAt: z.iso.datetime({ offset: true }),
  updatedAt: z.iso.datetime({ offset: true }),
  __v: z.number().int(),
});

/** Whole response */
export const BranchListResponseSchema = z.object({
  statusCode: z.number().int(),
  data: z.array(BranchListItemSchema),
  message: z.string(),
  success: z.boolean(),
});

export type BranchListResponse = z.infer<typeof BranchListResponseSchema>;
export type BranchListItem = z.infer<typeof BranchListItemSchema>;
