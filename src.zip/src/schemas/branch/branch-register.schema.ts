// src/schemas/branch-register.schema.ts
import { z } from "zod";

/** Reuse common pieces */
export const OperatingHourSchema = z.object({
  day: z.string(),
  open: z.string(),
  close: z.string(),
  isOpen: z.boolean(),
  _id: z.string(),
});

export const LocationSchema = z.object({
  adreessline1: z.string(), // keep spelling as-is (backend typo)
  addressline2: z.string(),
  city: z.string(),
  state: z.string(),
  pinCode: z.union([z.string(), z.number()]).transform(String),
  country: z.string(),
});

export const ContactSchema = z.object({
  mobile: z.string(),
  phone: z.string(),
  email: z.string().email(),
});

/** Newly registered branch object */
export const BranchRegisterDataSchema = z.object({
  _id: z.string(),
  name: z.string(),
  owner: z.array(z.string()),   // owner IDs
  location: LocationSchema,
  contact: ContactSchema,
  operatingHours: z.array(OperatingHourSchema),
  staff: z.array(z.unknown()),  // empty [] in your response, can hold staff later
  createdAt: z.string().datetime({ offset: true }),
  updatedAt: z.string().datetime({ offset: true }),
  __v: z.number().int(),
});

/** Full API response */
export const BranchRegisterResponseSchema = z.object({
  statusCode: z.number().int(),
  data: BranchRegisterDataSchema,
  message: z.string(),
  success: z.boolean(),
});

/** Inferred types */
export type BranchRegisterResponse = z.infer<typeof BranchRegisterResponseSchema>;
export type BranchRegisterData = z.infer<typeof BranchRegisterDataSchema>;
